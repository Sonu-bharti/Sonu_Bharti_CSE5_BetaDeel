import { Request, Response } from 'express';
import { z } from 'zod';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { User } from '../model/user.model';

// Zod validation schemas
const signupSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email format'),
  password: z.string().min(6, 'Password must be at least 6 characters')
});

const signinSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(6, 'Password must be at least 6 characters')
});

// Signup controller
export const signup = async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = signupSchema.parse(req.body);
    
    // Check if user already exists
    const existingUser = await User.findOne({ email: validatedData.email });
    if (existingUser) {
        res.status(400).json({ message: 'User already exists' });
        return 
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(validatedData.password, salt);

    // Create new user
    const newUser = new User({
      name: validatedData.name,
      email: validatedData.email,
      password: hashedPassword
    });

    await newUser.save();

    // Generate JWT token
    const token = jwt.sign(
      { userId: newUser._id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '1d' }
    );

    res.status(201).json({
      message: 'User created successfully',
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email
      }
    });
    return
  } catch (error) {
    if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
        return 
    }
    res.status(500).json({ message: 'Server error', error });
    return
  }
};

// Signin controller
export const signin = async (req: Request, res: Response) => {
  try {
    // Validate request body
    const validatedData = signinSchema.parse(req.body);

    // Find user
    const user = await User.findOne({ email: validatedData.email });
    if (!user) {
        res.status(401).json({ message: 'Invalid credentials' });
      return 
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(validatedData.password, user.password!);
    if (!isPasswordValid) {
        res.status(401).json({ message: 'Invalid credentials' });
      return 
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '1d' }
    );

    res.status(200).json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });
    return
  } catch (error) {
    if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      return 
    }
    res.status(500).json({ message: 'Server error', error });
    return
  }
};
