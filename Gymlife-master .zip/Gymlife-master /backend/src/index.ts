import 'dotenv/config'
import express, { Request, Response } from "express";
import mongoose from "mongoose";
import userRoutes from './routes/user.routes';
import cors from "cors";

const app = express();

// Middleware
app.use(express.json());

app.use(cors())

app.get("/", (req: Request, res : Response)=>{
res.json({
    message: "server is running fine!"
})
return
})

// Routes
app.use('/api/users', userRoutes);

const connectDatabase = async()=>{
try {
    await mongoose.connect(process.env.DATABASE_URL!)
    console.log("database connectd succesfully")
    main()
} catch (error) {
    console.log(error)
    process.exit(1)
} 
}

const main = ()=>{
    app.listen(8080, ()=>{
        console.log("server is running fine!")
    })
}

connectDatabase()