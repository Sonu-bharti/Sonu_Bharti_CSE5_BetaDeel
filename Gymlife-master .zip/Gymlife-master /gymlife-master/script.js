document.addEventListener('DOMContentLoaded', () => {
    const formContainer = document.querySelector('.form-container');
    const toggleButtons = document.querySelectorAll('.toggle');
    const inputs = document.querySelectorAll('input');
    const buttons = document.querySelectorAll('.btn');
    const signInForm = document.getElementById('signin-form');
    const signUpForm = document.getElementById('signup-form');

    // Toggle form animation
    toggleButtons.forEach(button => {
        button.addEventListener('click', () => {
            formContainer.classList.toggle('flip');
        });
    });

    // Input focus effects
    inputs.forEach(input => {
        input.addEventListener('focus', () => {
            input.parentElement.classList.add('focused');
        });

        input.addEventListener('blur', () => {
            if (!input.value) {
                input.parentElement.classList.remove('focused');
            }
        });
    });

    // Form validation and API calls
    buttons.forEach(button => {
        button.addEventListener('click', async (e) => {
            e.preventDefault();
            const form = button.closest('.form');
            const inputs = form.querySelectorAll('input');
            let isValid = true;
            const formData = {};

            inputs.forEach(input => {
                if (!input.value) {
                    isValid = false;
                    input.classList.add('error');
                    setTimeout(() => input.classList.remove('error'), 3000);
                } else {
                    formData[input.name] = input.value;
                }
                
                if (input.type === 'email' && !validateEmail(input.value)) {
                    isValid = false;
                    input.classList.add('error');
                    setTimeout(() => input.classList.remove('error'), 3000);
                }

                if (input.type === 'password' && input.value.length < 6) {
                    isValid = false;
                    input.classList.add('error');
                    setTimeout(() => input.classList.remove('error'), 3000);
                }
            });

            if (isValid) {
                button.classList.add('loading');
                
                try {
                    // Determine if it's a signup or signin form
                    const isSignUp = form.id === 'signup-form';
                    const endpoint = isSignUp 
                        ? 'http://localhost:8080/api/users/signup'
                        : 'http://localhost:8080/api/users/signin';
                    
                    const response = await fetch(endpoint, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(formData)
                    });
                    
                    const data = await response.json();
                    
                    if (!response.ok) {
                        throw new Error(data.message || 'Authentication failed');
                    }
                    
                    // Handle successful response
                    button.classList.remove('loading');
                    showSuccess(form);
                    
                    // Store the token if it exists in the response
                    if (data.token) {
                        localStorage.setItem('authToken', data.token);
                    }

                    // Store user's name for signup
                    if (isSignUp && formData.name) {
                        localStorage.setItem('userName', formData.name);
                    }
                    
                    // Redirect to dashboard after successful authentication
                    setTimeout(() => {
                        window.location.href = 'dashboard.html';
                    }, 2000);
                    
                } catch (error) {
                    button.classList.remove('loading');
                    showError(form, error.message);
                    console.error('Authentication error:', error);
                }
            }
        });
    });

    // Handle Sign In form submission
    signInForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = {
            email: signInForm.querySelector('[name="email"]').value,
            password: signInForm.querySelector('[name="password"]').value
        };

        try {
            const response = await fetch('/api/auth/signin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                const data = await response.json();
                // Store the authentication token
                localStorage.setItem('authToken', data.token);
                // Redirect to dashboard or home page
                window.location.href = '/dashboard.html';
            } else {
                throw new Error('Sign in failed');
            }
        } catch (error) {
            console.error('Sign in error:', error);
            alert('Sign in failed. Please try again.');
        }
    });

    // Handle Sign Up form submission
    signUpForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = {
            fullname: signUpForm.querySelector('[name="fullname"]').value,
            email: signUpForm.querySelector('[name="email"]').value,
            password: signUpForm.querySelector('[name="password"]').value
        };

        try {
            const response = await fetch('/api/auth/signup', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (response.ok) {
                const data = await response.json();
                // Store the authentication token
                localStorage.setItem('authToken', data.token);
                // Redirect to dashboard or home page
                window.location.href = '/dashboard.html';
            } else {
                throw new Error('Sign up failed');
            }
        } catch (error) {
            console.error('Sign up error:', error);
            alert('Sign up failed. Please try again.');
        }
    });

    function validateEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    function showSuccess(form) {
        const h1 = form.querySelector('h1');
        const originalText = h1.textContent;
        h1.textContent = 'Success! 🎉';
        setTimeout(() => {
            h1.textContent = originalText;
        }, 2000);
    }
    
    function showError(form, message) {
        const h1 = form.querySelector('h1');
        const originalText = h1.textContent;
        h1.textContent = message || 'Error! Please try again.';
        h1.style.color = 'red';
        
        setTimeout(() => {
            h1.textContent = originalText;
            h1.style.color = '';
        }, 3000);
    }
});